# Description
The main goal of this plugin is to facilitate the work of learning plan managers. It provides an overview of user learning plan, without leaving the page to get information related to this learning plan(such as rating in courses,user evidence,). It also offers statistics by learning plans and competencies. For learning plan templates with a very large number of learning plans (generated from cohorts), this plugin is the best solution, with its advanced filter, it allows you to filter the learning plans by several criteria.

Full documentation [here](https://studium.github.io/moodle-report_lpmonitoring/)
