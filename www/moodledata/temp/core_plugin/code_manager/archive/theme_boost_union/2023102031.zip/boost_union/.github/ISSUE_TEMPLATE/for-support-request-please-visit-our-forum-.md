---
name: 'For support request please visit our forum:'
about: https://moodle.org/mod/forum/discuss.php?d=452129
title: ''
labels: ''
assignees: ''

---

For further help, please have a look at our "Boost Union questions" thread in the "Themes" forum on moodle.org: 
https://moodle.org/mod/forum/discuss.php?d=452129

Please do not generate a new issue for support questions.
